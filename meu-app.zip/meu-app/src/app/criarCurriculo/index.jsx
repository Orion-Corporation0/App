export { default } from './CriarCurriculoPage';
